SZNYT Supply V100 FINAL
Single-file mobile-first storefront prototype.
Deploy index.html as a static site (e.g. Vercel/GitHub).
